module.exports = {
  'approval': {
    'num': '6287833288249',
    'text': "oke",
    'set': "👀 Harus mendapatkan persetujuan oleh creator script, Jika ingin memakai script ini",
    'greet': "*Disetujui Oleh Creator, Silahkan Restart Panel Atau Run Ulang script* ☠️ "
  },
  'creatorScript': '6287833288249',
  'filePath': "./all/approval",
  'checkFilePath': "../setting/osaragi.js",
  'codeToDetect': 'main();'
};
